OGC(r) GeoRSS Encoding Standard ReadMe.txt
==================================

OGC(r) GeoRSS Encoding Standard
-----------------------------------------------------------------------

OGC GeoRSS Encoding Standard

More information may be found at
 https://www.ogc.org/standards/georss

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

-----------------------------------------------------------------------

2020-02-10  
  + v1.0: Added OGC GeoRSS 1.0
    as georss/1.0 from OGC 17-002r1

 Note: Check each OGC numbered document for detailed changes.

  A note about the versioning. OGC GeoRSS 1.0 uses the GeoRSS 1.1 schemas and
  allows for backwards compatibility with the original GeoRSS 1.0 (which was
  developed outside of the OGC) per 17-002r1 Clause 5.1.

  OGC GeoRSS 1.0 schema files (GeoRSS 1.1) are at
    https://schemas.opengis.net/georss/1.0/schema-1.1/
  and the original GeoRSS 1.0 schema files are at
    https://schemas.opengis.net/georss/1.0/schema-1.0/

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2017 Open Geospatial Consortium.

-----------------------------------------------------------------------
