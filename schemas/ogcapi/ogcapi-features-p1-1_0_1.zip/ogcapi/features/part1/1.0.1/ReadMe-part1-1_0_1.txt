OGC(r) OGC API - Features ReadMe.txt
==================================

OGC(r) OGC API - Features
-----------------------------------------------------------------------

OGC API - Features

More information may be found at
 http://www.opengeospatial.org/standards/ogcapi-features

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/features/

-----------------------------------------------------------------------

2022-07-01 Clemens Portele, Panagiotis (Peter) A. Vretanos
  + v1.0: Added OGC API - Features - Part 2: Coordinate Reference Systems by Reference
    corrigendum 1.0.1
    as ogcapi/features/part2/1.0 from OGC 18-058r1

2022-07-01 Clemens Portele, Panagiotis (Peter) A. Vretanos, Charles Heazel
  + v1.0: Added OGC API - Features - Part 1: Core corrigendum 1.0.1
    as ogcapi/features/part1/1.0 from OGC 17-069r4

2021-05-03  Clemens Portele, Panagiotis (Peter) A. Vretanos
  + v1.0: Added OGC API - Features - Part 2:
    Coordinate Reference Systems by Reference 1.0
    as ogcapi/features/part2/1.0 from OGC 18-058

2019-10-11  Clemens Portele
  + v1.0: Added OGC API - Features - Part 1: Core 1.0
    as ogcapi/features/part1/1.0 from OGC 17-069r3

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2019, 2021, 2022 Open Geospatial Consortium.

-----------------------------------------------------------------------

