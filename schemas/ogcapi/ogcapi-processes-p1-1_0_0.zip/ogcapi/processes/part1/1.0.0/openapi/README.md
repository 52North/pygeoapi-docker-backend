# OGC API - Processes

The contents of this folder should be placed at http://schemas.opengis.net/ogcapi/processes/part1/1.0/openapi/

The ogcapi-processes-1.yaml file should be placed at

http://schemas.opengis.net/ogcapi/processes/part1/1.0/openapi/ogcapi-processes-1.yaml
