OGC(r) Web Services Security schema ReadMe.txt
==================================

OGC(r) Web Services Security (OWS Security) Standard

More information may be found at
 http://www.opengeospatial.org/standards/security

The most current schema are available at
http://schemas.opengis.net/security/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

-----------------------------------------------------------------------


2022-05-26  Andreas Matheus
  + v1.0: Change ISO/TC 211 schema locations
          from http://standards.iso.org to https://schemas.isotc211.org
          Version comment updated to 1.0.1 (06-135r11 s#13.4)

2019-02-07  OWS Common Security SWG
  + v1.0: published OWS Security 1.0.0 as security/1.0 from OGC 17-007r1

 Note: Check each OGC numbered document for detailed changes.


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2018-2022 Open Geospatial Consortium.

-----------------------------------------------------------------------

